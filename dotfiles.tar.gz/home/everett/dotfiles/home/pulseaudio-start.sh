#!/bin/bash
pulseaudio
