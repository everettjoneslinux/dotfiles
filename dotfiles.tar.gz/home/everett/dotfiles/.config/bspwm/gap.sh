#!/usr/bin/env bash

command=(bspc config window_gap)
window_gap="$(bspc config window_gap)"

case "$1" in 
    plus) 
        "${command[@]}" $(( window_gap + 2 ))
        ;;
    minus)
        "${command[@]}" $(( window_gap - 2 ))
        ;;
    equal)
        "${command[@]}" 0
        ;;
esac

